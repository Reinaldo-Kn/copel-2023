# PPE Detection > 2023-05-08 6:28pm
https://universe.roboflow.com/ufrgs-q7yg4/ppe-detection-vh98n

Provided by a Roboflow user
License: CC BY 4.0

